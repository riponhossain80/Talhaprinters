# PrintBD - Professional Printing App 🖨️

A complete Flutter + Firebase app for a printing business in Bangladesh.

---

## 📁 Project Structure

```
printing_app/
├── lib/
│   ├── main.dart                          ← App entry point
│   ├── core/
│   │   ├── constants/app_colors.dart      ← Orange + White color scheme
│   │   └── theme/app_theme.dart           ← Full Material 3 theme
│   ├── models/
│   │   └── models.dart                    ← User, Order, Product models
│   ├── providers/
│   │   └── providers.dart                 ← AuthProvider + CartProvider
│   ├── services/
│   │   └── price_calculator.dart          ← Auto price engine
│   └── screens/
│       ├── auth_splash_screens.dart       ← Splash, Login, OTP screens
│       ├── home/home_screen.dart          ← Home + Categories grid
│       ├── order/customize_screen.dart    ← Product customizer (live price)
│       └── order_profile_screens.dart     ← Cart, Checkout, Orders, Profile
├── pubspec.yaml                           ← All dependencies
└── firestore.rules                        ← Security rules
```

---

## 🚀 Setup Instructions

### 1. Create Firebase Project
1. Go to [console.firebase.google.com](https://console.firebase.google.com)
2. Create new project: "PrintBD"
3. Enable: **Authentication**, **Firestore**, **Storage**

### 2. Add Android App to Firebase
1. Android package name: `com.yourname.printingapp`
2. Download `google-services.json`
3. Place it in `android/app/google-services.json`

### 3. Enable Authentication Methods
- Go to Firebase Console → Authentication → Sign-in methods
- Enable **Phone** (OTP)
- Enable **Google**

### 4. Configure Android
Add to `android/build.gradle`:
```gradle
classpath 'com.google.gms:google-services:4.4.0'
```

Add to `android/app/build.gradle`:
```gradle
apply plugin: 'com.google.gms.google-services'

android {
    compileSdkVersion 34
    minSdkVersion 21
    ...
}
```

### 5. Install Dependencies
```bash
flutter pub get
```

### 6. Run the App
```bash
flutter run
```

---

## 💰 Price Calculator Logic

| Factor         | Effect                        |
|---------------|-------------------------------|
| Quantity      | Bulk discounts up to 30% off  |
| Paper Size    | A6=0.5x, A4=1x, A3=1.8x, etc |
| GSM           | 80gsm=1x, 300gsm=2.2x        |
| Color         | Full color=1x, B&W=0.5x      |
| Lamination    | +৳1.5/unit for matte/glossy  |
| Print Side    | Double side = 1.7x            |

---

## 📦 Key Features Built

- ✅ Splash screen with animation
- ✅ Phone OTP + Google login
- ✅ Home with 11 product categories
- ✅ Live price calculator (updates instantly)
- ✅ File upload (PDF, JPG, PNG, AI, CDR)
- ✅ Cart system
- ✅ Checkout with bKash/Nagad/Rocket/COD
- ✅ Order tracking with timeline
- ✅ My orders with real-time Firebase sync
- ✅ User profile
- ✅ Firestore security rules

---

## 🔧 Customize for Your Business

### Update Payment Numbers
In `checkout_screen.dart`:
```dart
const number = '01XXXXXXXXX'; // ← Your bKash/Nagad number
```

### Update Prices
In `lib/services/price_calculator.dart`:
```dart
static const Map<String, double> _basePrices = {
  'visiting_card': 2.5,  // ← BDT per piece
  'books': 15.0,
  // ...
};
```

### Add Your Logo
Replace the print icon in `splash_screen.dart` with:
```dart
Image.asset('assets/images/logo.png', width: 80, height: 80)
```

---

## 📱 Admin Panel
For admin, you can:
1. Use **FlutterFire Admin** or build a separate web admin panel
2. Or manage orders directly from **Firebase Console**
3. Set `isAdmin: true` in a user's Firestore document to grant admin access

---

## 🛠️ Next Steps
- [ ] Push notifications (FCM)
- [ ] Image compression before upload
- [ ] WhatsApp order confirmation
- [ ] Admin panel (separate Flutter Web app)
- [ ] Analytics dashboard
