// lib/screens/order/customize_screen.dart
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:provider/provider.dart';
import 'package:uuid/uuid.dart';
import '../../core/constants/app_colors.dart';
import '../../models/models.dart';
import '../../providers/providers.dart';
import '../../services/price_calculator.dart';
import 'checkout_screen.dart';

class CustomizeScreen extends StatefulWidget {
  final String categoryId;
  final String categoryName;

  const CustomizeScreen({
    super.key,
    required this.categoryId,
    required this.categoryName,
  });

  @override
  State<CustomizeScreen> createState() => _CustomizeScreenState();
}

class _CustomizeScreenState extends State<CustomizeScreen> {
  int _quantity = 100;
  String _paperSize = 'A4';
  int _paperGsm = 80;
  String _colorOption = 'full_color';
  String _laminationType = 'none';
  String _printSide = 'single';
  String? _uploadedFileName;
  String _deliveryCity = 'Dhaka';
  final _addressController = TextEditingController();
  final _phoneController = TextEditingController();
  final _notesController = TextEditingController();

  double get _price => PriceCalculator.calculatePrice(
    categoryId: widget.categoryId,
    quantity: _quantity,
    paperSize: _paperSize,
    paperGsm: _paperGsm,
    colorOption: _colorOption,
    laminationType: _laminationType,
    printSide: _printSide,
  );

  double get _deliveryCharge => PriceCalculator.getDeliveryCharge(_deliveryCity);
  double get _total => _price + _deliveryCharge;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.categoryName)),
      body: Column(
        children: [
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildSection('Quantity', _buildQuantitySelector()),
                  _buildSection('Paper Size', _buildDropdown(
                    value: _paperSize,
                    items: PriceCalculator.availableSizes,
                    onChanged: (v) => setState(() => _paperSize = v!),
                  )),
                  _buildSection('Paper GSM', _buildGsmSelector()),
                  _buildSection('Color Option', _buildRadioGroup(
                    options: PriceCalculator.colorOptions,
                    selected: _colorOption,
                    labelBuilder: PriceCalculator.colorLabel,
                    onChanged: (v) => setState(() => _colorOption = v),
                  )),
                  _buildSection('Print Side', _buildRadioGroup(
                    options: PriceCalculator.printSideOptions,
                    selected: _printSide,
                    labelBuilder: PriceCalculator.printSideLabel,
                    onChanged: (v) => setState(() => _printSide = v),
                  )),
                  _buildSection('Lamination', _buildDropdown(
                    value: _laminationType,
                    items: PriceCalculator.laminationOptions,
                    labelBuilder: PriceCalculator.laminationLabel,
                    onChanged: (v) => setState(() => _laminationType = v!),
                  )),
                  _buildSection('Upload Design File', _buildFileUpload()),
                  _buildSection('Delivery', _buildDeliverySection()),
                  _buildSection('Special Instructions', TextField(
                    controller: _notesController,
                    maxLines: 3,
                    decoration: const InputDecoration(
                        hintText: 'Any special instructions...'),
                  )),
                  const SizedBox(height: 16),
                ],
              ),
            ),
          ),
          _buildPriceBar(),
        ],
      ),
    );
  }

  Widget _buildSection(String title, Widget child) {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 8),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title,
              style: const TextStyle(
                  fontWeight: FontWeight.w600, fontSize: 14, color: AppColors.textPrimary)),
          const SizedBox(height: 12),
          child,
        ],
      ),
    );
  }

  Widget _buildQuantitySelector() {
    final presets = [50, 100, 250, 500, 1000, 2000, 5000];
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: presets.map((q) => GestureDetector(
            onTap: () => setState(() => _quantity = q),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
              decoration: BoxDecoration(
                color: _quantity == q ? AppColors.primary : Colors.grey.shade100,
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(
                q >= 1000 ? '${q ~/ 1000}K' : '$q',
                style: TextStyle(
                  color: _quantity == q ? Colors.white : AppColors.textPrimary,
                  fontWeight: FontWeight.w600,
                  fontSize: 13,
                ),
              ),
            ),
          )).toList(),
        ),
        const SizedBox(height: 12),
        Row(
          children: [
            const Text('Custom: ', style: TextStyle(fontSize: 13, color: AppColors.textSecondary)),
            SizedBox(
              width: 100,
              child: TextFormField(
                initialValue: '$_quantity',
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  isDense: true,
                ),
                onChanged: (v) {
                  final qty = int.tryParse(v);
                  if (qty != null && qty > 0) setState(() => _quantity = qty);
                },
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildDropdown({
    required String value,
    required List<String> items,
    String Function(String)? labelBuilder,
    required void Function(String?) onChanged,
  }) {
    return DropdownButtonFormField<String>(
      value: value,
      items: items.map((item) => DropdownMenuItem(
        value: item,
        child: Text(labelBuilder != null ? labelBuilder(item) : item),
      )).toList(),
      onChanged: onChanged,
      decoration: const InputDecoration(isDense: true),
    );
  }

  Widget _buildGsmSelector() {
    final gsmValues = PriceCalculator.availableGsmValues;
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: gsmValues.map((gsm) => GestureDetector(
        onTap: () => setState(() => _paperGsm = gsm),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
          decoration: BoxDecoration(
            color: _paperGsm == gsm ? AppColors.primary : Colors.grey.shade100,
            borderRadius: BorderRadius.circular(8),
          ),
          child: Text('$gsm gsm',
              style: TextStyle(
                color: _paperGsm == gsm ? Colors.white : AppColors.textPrimary,
                fontWeight: FontWeight.w600,
                fontSize: 13,
              )),
        ),
      )).toList(),
    );
  }

  Widget _buildRadioGroup({
    required List<String> options,
    required String selected,
    required String Function(String) labelBuilder,
    required void Function(String) onChanged,
  }) {
    return Column(
      children: options.map((opt) => RadioListTile<String>(
        title: Text(labelBuilder(opt), style: const TextStyle(fontSize: 14)),
        value: opt,
        groupValue: selected,
        onChanged: (v) => onChanged(v!),
        activeColor: AppColors.primary,
        dense: true,
        contentPadding: EdgeInsets.zero,
      )).toList(),
    );
  }

  Widget _buildFileUpload() {
    return Column(
      children: [
        GestureDetector(
          onTap: _pickFile,
          child: Container(
            height: 80,
            decoration: BoxDecoration(
              border: Border.all(
                  color: _uploadedFileName != null
                      ? AppColors.success
                      : AppColors.divider,
                  style: BorderStyle.solid),
              borderRadius: BorderRadius.circular(12),
              color: _uploadedFileName != null
                  ? AppColors.success.withOpacity(0.05)
                  : Colors.grey.shade50,
            ),
            child: Center(
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(
                    _uploadedFileName != null
                        ? Icons.check_circle
                        : Icons.upload_file,
                    color: _uploadedFileName != null
                        ? AppColors.success
                        : AppColors.textSecondary,
                  ),
                  const SizedBox(width: 8),
                  Text(
                    _uploadedFileName ?? 'Upload PDF, JPG, PNG, AI, CDR',
                    style: TextStyle(
                      color: _uploadedFileName != null
                          ? AppColors.success
                          : AppColors.textSecondary,
                      fontSize: 13,
                    ),
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
            ),
          ),
        ),
        if (_uploadedFileName != null)
          TextButton.icon(
            onPressed: () => setState(() => _uploadedFileName = null),
            icon: const Icon(Icons.close, size: 16, color: AppColors.error),
            label: const Text('Remove', style: TextStyle(color: AppColors.error, fontSize: 12)),
          ),
      ],
    );
  }

  Widget _buildDeliverySection() {
    final cities = [
      'Dhaka', 'Chittagong', 'Sylhet', 'Rajshahi',
      'Khulna', 'Barisal', 'Rangpur', 'Mymensingh', 'Other'
    ];
    return Column(
      children: [
        DropdownButtonFormField<String>(
          value: _deliveryCity,
          decoration: const InputDecoration(
              labelText: 'Delivery City', isDense: true),
          items: cities.map((c) =>
              DropdownMenuItem(value: c, child: Text(c))).toList(),
          onChanged: (v) => setState(() => _deliveryCity = v!),
        ),
        const SizedBox(height: 12),
        TextFormField(
          controller: _addressController,
          decoration: const InputDecoration(
              labelText: 'Full Delivery Address',
              hintText: 'House, Road, Area...',
              prefixIcon: Icon(Icons.location_on, color: AppColors.primary)),
          maxLines: 2,
        ),
        const SizedBox(height: 12),
        TextFormField(
          controller: _phoneController,
          keyboardType: TextInputType.phone,
          decoration: const InputDecoration(
              labelText: 'Contact Phone',
              prefixText: '+88 ',
              prefixIcon: Icon(Icons.phone, color: AppColors.primary)),
        ),
      ],
    );
  }

  Widget _buildPriceBar() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.08), blurRadius: 12, offset: const Offset(0, -4)),
        ],
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('Print Cost ($_quantity pcs)', style: const TextStyle(color: AppColors.textSecondary, fontSize: 13)),
              Text('৳${_price.toStringAsFixed(0)}', style: const TextStyle(fontWeight: FontWeight.w600)),
            ],
          ),
          const SizedBox(height: 4),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text('Delivery (${_deliveryCity})', style: TextStyle(color: AppColors.textSecondary, fontSize: 13)),
              Text('৳${_deliveryCharge.toStringAsFixed(0)}', style: const TextStyle(fontWeight: FontWeight.w600)),
            ],
          ),
          const Divider(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text('Total', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
              Text('৳${_total.toStringAsFixed(0)}',
                  style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 20, color: AppColors.primary)),
            ],
          ),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              icon: const Icon(Icons.shopping_cart_rounded),
              label: const Text('Add to Cart'),
              onPressed: _addToCart,
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _pickFile() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['pdf', 'jpg', 'jpeg', 'png', 'ai', 'cdr'],
    );
    if (result != null && result.files.isNotEmpty) {
      setState(() => _uploadedFileName = result.files.first.name);
    }
  }

  void _addToCart() {
    if (_addressController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Please enter delivery address'),
              backgroundColor: AppColors.error));
      return;
    }

    final customization = ProductCustomization(
      categoryId: widget.categoryId,
      categoryName: widget.categoryName,
      quantity: _quantity,
      paperSize: _paperSize,
      paperGsm: _paperGsm,
      colorOption: _colorOption,
      laminationType: _laminationType,
      printSide: _printSide,
      uploadedFileName: _uploadedFileName,
      deliveryAddress: _addressController.text.trim(),
      deliveryCity: _deliveryCity,
      phoneNumber: _phoneController.text.trim(),
      specialInstructions: _notesController.text.trim(),
      calculatedPrice: _total,
    );

    context.read<CartProvider>().addItem(CartItem(
      id: const Uuid().v4(),
      customization: customization.toMap(),
      price: _total,
    ));

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('${widget.categoryName} added to cart!'),
        backgroundColor: AppColors.success,
        action: SnackBarAction(
          label: 'View Cart',
          textColor: Colors.white,
          onPressed: () => Navigator.push(context,
              MaterialPageRoute(builder: (_) => const CartScreen())),
        ),
      ),
    );
  }
}
