// lib/models/product_model.dart
import 'package:cloud_firestore/cloud_firestore.dart';

class ProductCategory {
  final String id;
  final String name;
  final String icon;
  final String imageUrl;
  final bool isActive;

  ProductCategory({
    required this.id,
    required this.name,
    required this.icon,
    required this.imageUrl,
    this.isActive = true,
  });

  factory ProductCategory.fromMap(Map<String, dynamic> map, String id) {
    return ProductCategory(
      id: id,
      name: map['name'] ?? '',
      icon: map['icon'] ?? '',
      imageUrl: map['imageUrl'] ?? '',
      isActive: map['isActive'] ?? true,
    );
  }

  Map<String, dynamic> toMap() => {
    'name': name,
    'icon': icon,
    'imageUrl': imageUrl,
    'isActive': isActive,
  };
}

class PaperSize {
  final String name;
  final double multiplier;
  PaperSize({required this.name, required this.multiplier});
}

class ProductCustomization {
  String categoryId;
  String categoryName;
  int quantity;
  String paperSize;
  int paperGsm;
  String colorOption; // 'full_color', 'black_white'
  String laminationType; // 'none', 'matte', 'glossy'
  String printSide; // 'single', 'double'
  String? uploadedFileUrl;
  String? uploadedFileName;
  String deliveryAddress;
  String deliveryCity;
  String phoneNumber;
  String? specialInstructions;
  double calculatedPrice;

  ProductCustomization({
    required this.categoryId,
    required this.categoryName,
    this.quantity = 100,
    this.paperSize = 'A4',
    this.paperGsm = 80,
    this.colorOption = 'full_color',
    this.laminationType = 'none',
    this.printSide = 'single',
    this.uploadedFileUrl,
    this.uploadedFileName,
    this.deliveryAddress = '',
    this.deliveryCity = '',
    this.phoneNumber = '',
    this.specialInstructions,
    this.calculatedPrice = 0.0,
  });

  Map<String, dynamic> toMap() => {
    'categoryId': categoryId,
    'categoryName': categoryName,
    'quantity': quantity,
    'paperSize': paperSize,
    'paperGsm': paperGsm,
    'colorOption': colorOption,
    'laminationType': laminationType,
    'printSide': printSide,
    'uploadedFileUrl': uploadedFileUrl,
    'uploadedFileName': uploadedFileName,
    'deliveryAddress': deliveryAddress,
    'deliveryCity': deliveryCity,
    'phoneNumber': phoneNumber,
    'specialInstructions': specialInstructions,
    'calculatedPrice': calculatedPrice,
  };
}

// lib/models/order_model.dart
class OrderModel {
  final String id;
  final String userId;
  final String userName;
  final String userPhone;
  final List<Map<String, dynamic>> items;
  final double subtotal;
  final double deliveryCharge;
  final double totalAmount;
  final String paymentMethod;
  final String paymentStatus;
  final String orderStatus;
  final DateTime createdAt;
  final String deliveryAddress;

  OrderModel({
    required this.id,
    required this.userId,
    required this.userName,
    required this.userPhone,
    required this.items,
    required this.subtotal,
    required this.deliveryCharge,
    required this.totalAmount,
    required this.paymentMethod,
    this.paymentStatus = 'pending',
    this.orderStatus = 'pending',
    required this.createdAt,
    required this.deliveryAddress,
  });

  factory OrderModel.fromMap(Map<String, dynamic> map, String id) {
    return OrderModel(
      id: id,
      userId: map['userId'] ?? '',
      userName: map['userName'] ?? '',
      userPhone: map['userPhone'] ?? '',
      items: List<Map<String, dynamic>>.from(map['items'] ?? []),
      subtotal: (map['subtotal'] ?? 0).toDouble(),
      deliveryCharge: (map['deliveryCharge'] ?? 0).toDouble(),
      totalAmount: (map['totalAmount'] ?? 0).toDouble(),
      paymentMethod: map['paymentMethod'] ?? '',
      paymentStatus: map['paymentStatus'] ?? 'pending',
      orderStatus: map['orderStatus'] ?? 'pending',
      createdAt: (map['createdAt'] as Timestamp).toDate(),
      deliveryAddress: map['deliveryAddress'] ?? '',
    );
  }

  Map<String, dynamic> toMap() => {
    'userId': userId,
    'userName': userName,
    'userPhone': userPhone,
    'items': items,
    'subtotal': subtotal,
    'deliveryCharge': deliveryCharge,
    'totalAmount': totalAmount,
    'paymentMethod': paymentMethod,
    'paymentStatus': paymentStatus,
    'orderStatus': orderStatus,
    'createdAt': Timestamp.fromDate(createdAt),
    'deliveryAddress': deliveryAddress,
  };

  String get statusLabel {
    switch (orderStatus) {
      case 'pending': return 'Pending';
      case 'designing': return 'Designing';
      case 'printing': return 'Printing';
      case 'ready': return 'Ready';
      case 'delivered': return 'Delivered';
      case 'cancelled': return 'Cancelled';
      default: return 'Unknown';
    }
  }
}

// lib/models/user_model.dart
class UserModel {
  final String uid;
  String name;
  String phone;
  String email;
  String? photoUrl;
  String? defaultAddress;
  DateTime createdAt;

  UserModel({
    required this.uid,
    required this.name,
    required this.phone,
    this.email = '',
    this.photoUrl,
    this.defaultAddress,
    required this.createdAt,
  });

  factory UserModel.fromMap(Map<String, dynamic> map, String uid) {
    return UserModel(
      uid: uid,
      name: map['name'] ?? '',
      phone: map['phone'] ?? '',
      email: map['email'] ?? '',
      photoUrl: map['photoUrl'],
      defaultAddress: map['defaultAddress'],
      createdAt: map['createdAt'] != null
          ? (map['createdAt'] as Timestamp).toDate()
          : DateTime.now(),
    );
  }

  Map<String, dynamic> toMap() => {
    'name': name,
    'phone': phone,
    'email': email,
    'photoUrl': photoUrl,
    'defaultAddress': defaultAddress,
    'createdAt': Timestamp.fromDate(createdAt),
  };
}
