// lib/services/price_calculator.dart

class PriceCalculator {
  // Base prices per unit (in BDT)
  static const Map<String, double> _basePrices = {
    'visiting_card': 2.5,
    'books': 15.0,
    'cash_memo': 3.0,
    'letterhead': 4.0,
    'leaflet': 3.5,
    'banner': 80.0,
    'poster': 25.0,
    'id_card': 30.0,
    'sticker': 5.0,
    'brochure': 8.0,
    'packaging': 20.0,
  };

  // GSM multipliers
  static const Map<int, double> _gsmMultiplier = {
    80: 1.0,
    100: 1.15,
    120: 1.25,
    150: 1.40,
    200: 1.65,
    250: 1.90,
    300: 2.20,
    350: 2.50,
  };

  // Paper size multipliers
  static const Map<String, double> _sizeMultiplier = {
    'A6': 0.5,
    'A5': 0.75,
    'A4': 1.0,
    'A3': 1.8,
    'A2': 3.5,
    'A1': 7.0,
    'Business Card': 0.3,
    'Custom': 1.0,
  };

  // Color multipliers
  static const Map<String, double> _colorMultiplier = {
    'full_color': 1.0,
    'black_white': 0.5,
    'spot_color': 0.75,
  };

  // Lamination prices per unit
  static const Map<String, double> _laminationPrice = {
    'none': 0.0,
    'matte': 1.5,
    'glossy': 1.5,
    'soft_touch': 2.5,
  };

  // Print side multiplier
  static const Map<String, double> _printSideMultiplier = {
    'single': 1.0,
    'double': 1.7,
  };

  // Quantity discount tiers
  static double _quantityDiscount(int quantity) {
    if (quantity >= 5000) return 0.30;
    if (quantity >= 2000) return 0.20;
    if (quantity >= 1000) return 0.15;
    if (quantity >= 500) return 0.10;
    if (quantity >= 250) return 0.05;
    return 0.0;
  }

  // Delivery charges by city
  static const Map<String, double> _deliveryCharges = {
    'Dhaka': 60.0,
    'Chittagong': 100.0,
    'Sylhet': 120.0,
    'Rajshahi': 120.0,
    'Khulna': 120.0,
    'Barisal': 130.0,
    'Rangpur': 130.0,
    'Mymensingh': 100.0,
    'Other': 150.0,
  };

  static double calculatePrice({
    required String categoryId,
    required int quantity,
    required String paperSize,
    required int paperGsm,
    required String colorOption,
    required String laminationType,
    required String printSide,
  }) {
    double basePrice = _basePrices[categoryId] ?? 5.0;
    double sizeM = _sizeMultiplier[paperSize] ?? 1.0;
    double gsmM = _gsmMultiplier[paperGsm] ?? 1.0;
    double colorM = _colorMultiplier[colorOption] ?? 1.0;
    double laminationP = _laminationPrice[laminationType] ?? 0.0;
    double sideM = _printSideMultiplier[printSide] ?? 1.0;
    double discount = _quantityDiscount(quantity);

    // Unit price calculation
    double unitPrice = basePrice * sizeM * gsmM * colorM * sideM;
    unitPrice += laminationP;

    // Total before discount
    double totalBeforeDiscount = unitPrice * quantity;

    // Apply quantity discount
    double total = totalBeforeDiscount * (1 - discount);

    // Minimum order charge
    if (total < 150) total = 150;

    return double.parse(total.toStringAsFixed(2));
  }

  static double getDeliveryCharge(String city) {
    return _deliveryCharges[city] ?? _deliveryCharges['Other']!;
  }

  static List<int> get availableGsmValues =>
      [80, 100, 120, 150, 200, 250, 300, 350];

  static List<String> get availableSizes =>
      ['Business Card', 'A6', 'A5', 'A4', 'A3', 'A2', 'A1', 'Custom'];

  static List<String> get colorOptions =>
      ['full_color', 'black_white', 'spot_color'];

  static List<String> get laminationOptions =>
      ['none', 'matte', 'glossy', 'soft_touch'];

  static List<String> get printSideOptions => ['single', 'double'];

  static String colorLabel(String key) {
    const labels = {
      'full_color': 'Full Color (CMYK)',
      'black_white': 'Black & White',
      'spot_color': 'Spot Color',
    };
    return labels[key] ?? key;
  }

  static String laminationLabel(String key) {
    const labels = {
      'none': 'No Lamination',
      'matte': 'Matte Lamination',
      'glossy': 'Glossy Lamination',
      'soft_touch': 'Soft Touch',
    };
    return labels[key] ?? key;
  }

  static String printSideLabel(String key) {
    const labels = {
      'single': 'Single Side',
      'double': 'Double Side',
    };
    return labels[key] ?? key;
  }
}
