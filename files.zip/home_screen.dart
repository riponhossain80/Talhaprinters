// lib/screens/home/home_screen.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:badges/badges.dart' as badges;
import '../../core/constants/app_colors.dart';
import '../../providers/providers.dart';
import '../order/customize_screen.dart';
import '../order/cart_screen.dart';
import '../order/my_orders_screen.dart';
import '../profile/profile_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _currentIndex = 0;

  final List<Map<String, dynamic>> _categories = [
    {'id': 'visiting_card', 'name': 'Visiting Card', 'icon': Icons.credit_card, 'color': Color(0xFF6366F1)},
    {'id': 'books', 'name': 'Books', 'icon': Icons.book, 'color': Color(0xFF10B981)},
    {'id': 'cash_memo', 'name': 'Cash Memo', 'icon': Icons.receipt, 'color': Color(0xFFF59E0B)},
    {'id': 'letterhead', 'name': 'Letterhead', 'icon': Icons.article, 'color': Color(0xFF3B82F6)},
    {'id': 'leaflet', 'name': 'Leaflet/Flyer', 'icon': Icons.layers, 'color': Color(0xFFEC4899)},
    {'id': 'banner', 'name': 'Banner', 'icon': Icons.flag, 'color': Color(0xFF8B5CF6)},
    {'id': 'poster', 'name': 'Poster', 'icon': Icons.image, 'color': Color(0xFFEF4444)},
    {'id': 'id_card', 'name': 'ID Card', 'icon': Icons.badge, 'color': Color(0xFF06B6D4)},
    {'id': 'sticker', 'name': 'Sticker', 'icon': Icons.star, 'color': Color(0xFFF97316)},
    {'id': 'brochure', 'name': 'Brochure', 'icon': Icons.menu_book, 'color': Color(0xFF84CC16)},
    {'id': 'packaging', 'name': 'Packaging', 'icon': Icons.inventory_2, 'color': Color(0xFF14B8A6)},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(
        index: _currentIndex,
        children: const [
          _HomeTab(),
          MyOrdersScreen(),
          ProfileScreen(),
        ],
      ),
      bottomNavigationBar: Consumer<CartProvider>(
        builder: (_, cart, __) => BottomNavigationBar(
          currentIndex: _currentIndex,
          onTap: (i) => setState(() => _currentIndex = i),
          items: [
            const BottomNavigationBarItem(
                icon: Icon(Icons.home_rounded), label: 'Home'),
            BottomNavigationBarItem(
                icon: badges.Badge(
                  showBadge: cart.itemCount > 0,
                  badgeContent: Text('${cart.itemCount}',
                      style: const TextStyle(color: Colors.white, fontSize: 10)),
                  child: const Icon(Icons.receipt_long_rounded),
                ),
                label: 'Orders'),
            const BottomNavigationBarItem(
                icon: Icon(Icons.person_rounded), label: 'Profile'),
          ],
        ),
      ),
    );
  }
}

class _HomeTab extends StatelessWidget {
  const _HomeTab();

  final List<Map<String, dynamic>> categories = const [
    {'id': 'visiting_card', 'name': 'Visiting Card', 'icon': Icons.credit_card, 'color': Color(0xFF6366F1)},
    {'id': 'books', 'name': 'Books', 'icon': Icons.book, 'color': Color(0xFF10B981)},
    {'id': 'cash_memo', 'name': 'Cash Memo', 'icon': Icons.receipt, 'color': Color(0xFFF59E0B)},
    {'id': 'letterhead', 'name': 'Letterhead', 'icon': Icons.article, 'color': Color(0xFF3B82F6)},
    {'id': 'leaflet', 'name': 'Leaflet/Flyer', 'icon': Icons.layers, 'color': Color(0xFFEC4899)},
    {'id': 'banner', 'name': 'Banner', 'icon': Icons.flag, 'color': Color(0xFF8B5CF6)},
    {'id': 'poster', 'name': 'Poster', 'icon': Icons.image, 'color': Color(0xFFEF4444)},
    {'id': 'id_card', 'name': 'ID Card', 'icon': Icons.badge, 'color': Color(0xFF06B6D4)},
    {'id': 'sticker', 'name': 'Sticker', 'icon': Icons.star, 'color': Color(0xFFF97316)},
    {'id': 'brochure', 'name': 'Brochure', 'icon': Icons.menu_book, 'color': Color(0xFF84CC16)},
    {'id': 'packaging', 'name': 'Packaging', 'icon': Icons.inventory_2, 'color': Color(0xFF14B8A6)},
  ];

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    return Scaffold(
      backgroundColor: AppColors.background,
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            expandedHeight: 180,
            floating: false,
            pinned: true,
            backgroundColor: AppColors.primary,
            actions: [
              Consumer<CartProvider>(
                builder: (_, cart, __) => badges.Badge(
                  showBadge: cart.itemCount > 0,
                  badgeContent: Text('${cart.itemCount}',
                      style: const TextStyle(color: Colors.white, fontSize: 10)),
                  child: IconButton(
                    icon: const Icon(Icons.shopping_cart_rounded, color: Colors.white),
                    onPressed: () => Navigator.push(context,
                        MaterialPageRoute(builder: (_) => const CartScreen())),
                  ),
                ),
              ),
              const SizedBox(width: 8),
            ],
            flexibleSpace: FlexibleSpaceBar(
              background: Container(
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [AppColors.primary, AppColors.primaryDark],
                  ),
                ),
                padding: const EdgeInsets.fromLTRB(20, 80, 20, 20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    Text(
                      'Hello, ${auth.userModel?.name.split(' ').first ?? 'There'}! 👋',
                      style: const TextStyle(
                          color: Colors.white70, fontSize: 14),
                    ),
                    const SizedBox(height: 4),
                    const Text(
                      'What would you like\nto print today?',
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 22,
                          fontWeight: FontWeight.bold),
                    ),
                  ],
                ),
              ),
            ),
            title: const Text('PrintBD',
                style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Banner
                  Container(
                    height: 120,
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        colors: [Color(0xFFFF6B00), Color(0xFFFFB347)],
                      ),
                      borderRadius: BorderRadius.circular(16),
                    ),
                    padding: const EdgeInsets.all(20),
                    child: Row(
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: const [
                              Text('Special Offer!',
                                  style: TextStyle(color: Colors.white70, fontSize: 12)),
                              SizedBox(height: 4),
                              Text('20% OFF\non first order',
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 20,
                                      fontWeight: FontWeight.bold)),
                            ],
                          ),
                        ),
                        const Icon(Icons.local_offer_rounded,
                            color: Colors.white, size: 60),
                      ],
                    ),
                  ),
                  const SizedBox(height: 24),
                  const Text('Our Services',
                      style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: AppColors.textPrimary)),
                  const SizedBox(height: 16),
                ],
              ),
            ),
          ),
          SliverPadding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            sliver: SliverGrid(
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 3,
                mainAxisSpacing: 12,
                crossAxisSpacing: 12,
                childAspectRatio: 0.9,
              ),
              delegate: SliverChildBuilderDelegate(
                (context, index) {
                  final cat = categories[index];
                  return _CategoryCard(
                    name: cat['name'],
                    icon: cat['icon'],
                    color: cat['color'],
                    onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => CustomizeScreen(
                          categoryId: cat['id'],
                          categoryName: cat['name'],
                        ),
                      ),
                    ),
                  );
                },
                childCount: categories.length,
              ),
            ),
          ),
          const SliverPadding(padding: EdgeInsets.only(bottom: 24)),
        ],
      ),
    );
  }
}

class _CategoryCard extends StatelessWidget {
  final String name;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;

  const _CategoryCard({
    required this.name,
    required this.icon,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: color.withOpacity(0.15),
              blurRadius: 10,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 52,
              height: 52,
              decoration: BoxDecoration(
                color: color.withOpacity(0.1),
                borderRadius: BorderRadius.circular(14),
              ),
              child: Icon(icon, color: color, size: 28),
            ),
            const SizedBox(height: 10),
            Text(
              name,
              textAlign: TextAlign.center,
              style: const TextStyle(
                fontSize: 11,
                fontWeight: FontWeight.w600,
                color: AppColors.textPrimary,
              ),
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
          ],
        ),
      ),
    );
  }
}
